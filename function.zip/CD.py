def CD(alist,indent=False,level=0):
        for each_item in alist:
                if isinstance(each_item,list):
                        CD(each_item,indent,level+1)
                else:
                        if indent:
                                for tab_stop in range(level):
                                        print("\t\n")
                        print(each_item)
